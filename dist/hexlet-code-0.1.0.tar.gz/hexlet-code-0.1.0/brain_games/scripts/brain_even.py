#!/usr/bin/env python3


import random
import prompt


def main():
    name = prompt.string('May I have your name? ')
    print('Hello, ' + name + '!')
    print('Answer "yes" if the number is even, otherwise answer "no".')
    tries = 0
    while tries < 3:
        random_number = random.randint(0, 1000)
        tries = tries + 1
        print('Question:', random_number)
        answer = prompt.string('Your answer: ')
        if random_number % 2 == 0:
            if answer == 'yes':
                print('Correct!')
            if answer == 'no':          
                print('"no" is wrong answer ;(. Correct answer was "yes".' + "\nLet's try again, " + name + '!')
                break
            if answer != 'yes' and answer != 'no':
                print(answer + ' is wrong answer ;(. Correct answer was "yes".' + "\nLet's try again, " + name + '!')
                break
        if random_number % 2 > 0:
            if answer == 'yes':
                print('"yes" is wrong answer ;(. Correct answer was "no".' + "\nLet's try again, " + name + '!')
                break
            if answer == 'no':
                print('Correct!')
            if answer != 'yes' and answer != 'no':
                print(answer + ' is wrong answer ;(. Correct answer was "no".' + "\nLet's try again, " + name + '!')
                break
    if tries >= 3:
        print('Congratulations, ' + name + '!')


if __name__ == '__main__':
    main()
