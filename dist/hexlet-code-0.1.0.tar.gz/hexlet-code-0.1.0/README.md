### Hexlet tests and linter status:
[![Actions Status](https://github.com/MariaRegin/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/MariaRegin/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/d27e6bb872a8a06aad89/maintainability)](https://codeclimate.com/github/MariaRegin/python-project-49/maintainability)
https://asciinema.org/a/dXMjE5Ppkf1Rr1wG7SRdi6xke
